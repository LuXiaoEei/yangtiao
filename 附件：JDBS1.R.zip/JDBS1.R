#B����������㣬2016��06�¼��˫�����������μ��һ������

library(splines)
library(MASS)
#����ڴ����
rm(list=ls())
gc()
##����������
n<- 500
sigmaeps<- 0.1
########### ����ģ�����
N<- 1000
############��������
gu<-function(u)
{k<-length(u)
f1<-rep(0,k)
for (i in 1:k) {
  if (u[i]<0.3) {
    f1[i]<--3*u[i]+2
  }else {
    if(u[i]>=0.7) {
      f1[i]<-u[i]/2+1.55
    }else {
      f1[i]<--3*u[i]+3-sin((u[i]-0.3)*pi/0.2)
    }
  }
}
return(f1)
}

alpha<- 0.05
###############################
low<- 12
up<- 16
BIC<- matrix(rep(0),3,up-low+1)
ufix<- seq(0,1,length.out = 201)
yfix<- matrix(rep(0),201,N)
ISE<- ISE3<- ISE7<-lambdaM<- rep(0,N)
#########################################
interp<- function(y,x,x0){
  n<- length(x0)
  yhat<- matrix(rep(0),n,1)
  n1<- length(x)
  for (i in 1:n) {
    a<- abs(x-x0[i])
    yhat[i]<- y[order(a)[1]]
  }
  return(yhat)
}
###### crt�ǰ�����ȷ����Ĵ��������ܶ��
rt<- more<- less<- error<-crt<- 0
Nt<- 1
jumps.list<-  list()
jumps<- c()
system.time(
  while(Nt<N+1){
    jumps2<- c()
    cat('Simulation ', Nt,'\n')
    ####   ����ȡ�㲽��
    u1<- seq(0.11,0.89,by=0.001)
    nu1<- length(u1)
    DRSStotal<- matrix(rep(0),nu1,1)
    ###############   �����������
    eps<- rnorm(n,0,sigmaeps)
    uj<- runif(n,0,1)
    yj<- gu(uj)+eps
    #############����sigmaeps
    yjs<- yj[order(uj)]
    sigmahat<- 1/2*1/(n-1)*sum((yjs[-1]-yjs[-n])^2)
    sigmahat
    
    ####### BIC׼��ѡ��ڵ�
    for(k in low:up){
      for(degree in 1:3){
        u0<- seq(0.1,0.9,length.out = k)
        fit1<- lm(yj ~ bs(uj, degree = degree, knots = u0,Boundary.knots = c(0,1),intercept=T)-1)
        RSS0<- sum(fit1$residuals^2)
        BIC[degree,k-low+1]<- log(RSS0/n)+(k+degree+1)/n*log(n)
      }
    }
    k0<- ceiling(which.min(BIC)/3)+low-1
    degree<- (which.min(BIC)-1)%%3+1
    q2<- qchisq(1-alpha,degree+1)
    err<-  0.8/(k0-1)
    cat('k0=',k0,'degree=',degree,'\n')
    
    u0<- seq(0.1,0.9,length.out = k0)
    nu0<- length(u0)
    #############
    for(NJ in 1:5){
      fit1<- lm(yj ~ bs(uj, degree = degree, knots = u0,Boundary.knots = c(0,1),intercept=T)-1)
      yfit1<- fitted(fit1)
      RSS0<- sum(fit1$residuals^2)
      DRSSu<- rep(0,nu1)
      for(i in 1:nu1){
        us<- u0
        m=which(u0==u1[i])
        if(length(m)>0){
          us<- c(u0[-m],rep(u1[i],degree+1))
          us<- sort(us)
          DRSStotal[i]<- NA
        }else{
          us<- c(u0,rep(u1[i],degree+1))
          us<- sort(us)
          fit2<- lm(yj ~ bs(uj, degree = degree, knots = us,Boundary.knots = c(0,1),intercept=T)-1)
          yfit2<- fitted(fit2)
          DRSStotal[i]<- sum((yfit1-yfit2)^2)
        }
      }
      lambda<- mean(DRSStotal,na.rm = TRUE)/sigmahat-degree-1
      #cat('lambda=',lambda,'\n')
      if(lambda<=0) break
      #lambda<- max(lambda,0)
      #lambdaM[Nt]<- lambda
      q2<- qchisq(1-alpha,degree+1,lambda)*sigmahat
      #plot(u1,DRSStotal,main = paste('Simulation',Nt))
      #abline(h=q2,col='red')
      ### ������
      id<- which(DRSStotal>q2) 
      if(length(id)>0){
        nx<- which(DRSStotal==max(DRSStotal,na.rm = TRUE))
        u.jump<- mean(u1[nx])
        #�ж��������Ƿ���ԭ���㸽��
        if(length(jumps2)>0){
          j2<- abs(jumps2-u.jump)
          j2<- min(j2)
          if(j2<err)break
        }
        ########## 
        jumps<- c(jumps,u.jump)
        jumps2<- c(jumps2,u.jump)
        cat(u.jump,'\n')
        #���������
        du<- abs(u0-u.jump)
        m<- which(du==min(du))
        m<- m[1]
        if(du[m]<err/2){
          u0<- c(u0[-m],rep(u.jump,degree+1))
          u0<- sort(u0)
        }else{
          u0<- c(u0,rep(u.jump,degree+1))
          u0<- sort(u0)
        }
      }else{
        break
      }
    }
    
    s1<- length(which(jumps2>0.25&jumps2<0.35))
    s2<- length(which(jumps2>0.65&jumps2<0.75))
    
    fit1<- lm(yj ~ bs(uj, degree = degree, knots = u0,Boundary.knots = c(0,1),intercept=T)-1)
    y1<- fitted(fit1)
    yfix[,Nt]<- interp(y1,uj,ufix)
    jumps.list[[Nt]]<- jumps2
    
    #����MISE
    ISE[Nt]<- sum((y1-gu(uj))^2)/n
    id1<- which((uj<0.35)&(uj>0.25))
    ISE3[Nt]<- sum((y1[id1]-gu(uj[id1]))^2)/n
    id2<- which((uj<0.75)&(uj>0.65))
    ISE7[Nt]<- sum((y1[id2]-gu(uj[id2]))^2)/n
    Nt<- Nt+1
  }
)

MISE<- mean(ISE)
MISE3<- mean(ISE3)
MISE7<- mean(ISE7)
cat('Mean lambda=',mean(lambdaM))
cat('MISE=',MISE,'MISE0.3=',MISE3,'MISE0.7=',MISE7,'LMISE=',MISE3+MISE7)


yfinal<- apply(yfix,1,mean)
#####  ��ͼ  #########
mytitle<- paste('N=',N,'n=',n,'sigma=',sigmaeps)
plot(ufix,yfinal,type = 'l',lty=2,col='blue',xlim=c(0,1),ylim=c(0.5,2.5),
     xlab="x",ylab="y",main=mytitle)
lines(ufix,gu(ufix),col='red')
#points(uj,yj)

# ��������
mytitle<- paste('N=',N,'n=',n,'sigma=',sigmaeps)
plot(ufix,yfinal,type = 'l',lty=2,col='blue',xlim=c(0,1),ylim=c(0.5,2.5),
     xlab="x",ylab="y",main=mytitle)
lines(ufix,gu(ufix),col='red')
fL<-apply(yfix,1,quantile,probs = c(0.05,0.95))
lines(ufix,fL[1,],col='blue')
lines(ufix,fL[2,],col='blue')

####### ���ܶȹ���
plot(density(jumps,bw = 0.015,kernel = 'gaussian'),xlim=c(0,1))
J1<- which(jumps<0.35&jumps>0.25)
mean3<- mean(jumps[J1])
sd3<- sd(jumps[J1])
J2<- which(jumps<0.75&jumps>0.65)
mean7<- mean(jumps[J2])
sd7<- sd(jumps[J2])
cat('at 0.3, bias=',mean3-0.3,'sd=',sd3,'power=',length(jumps[J1])/N,'\n')
cat('at 0.7, bias=',mean7-0.7,'sd=',sd7,'power=',length(jumps[J2])/N,'\n')
Len<- rep(0,N)
for(i in 1:N){
  Len[i]<- length(jumps.list[[i]])
}
cat(sum(Len==0),sum(Len==1),sum(Len==2),sum(Len==3),sum(Len>3),'\n')
cat('Total jumps=',length(jumps),'\n')
#save.image('RSSout0613RData')