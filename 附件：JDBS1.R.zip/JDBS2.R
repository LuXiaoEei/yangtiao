#B����������㣬2016��06�¼��˫��������˫���ڳ�

library(splines)
library(MASS)
#����ڴ����
rm(list=ls())
gc()
##����������
n<- 500
sigmaeps<- 0.1
########### ����ģ�����
N<- 1000
############��������
gu<-function(u)
{k<-length(u)
f1<-rep(0,k)
for (i in 1:k) {
  if (u[i]<0.3) {
    f1[i]<--3*u[i]+2
  }else {
    if(u[i]>=0.7) {
      f1[i]<-u[i]/2+1.55
    }else {
      f1[i]<--3*u[i]+3-sin((u[i]-0.3)*pi/0.2)
    }
  }
}
return(f1)
}

alpha<- 0.05
###############################
low<- 12
up<- 16
BIC<- matrix(rep(0),3,up-low+1)
ufix<- seq(0,1,length.out = 201)
yfix<- matrix(rep(0),201,N)
ISE<- ISE3<- ISE7<-lambdaM<- rep(0,N)
#########################################
findindex<-function(id){
  n<- length(id)
  if(n==1) {
    return(id)
  }
  idd<- diff(id)
  j<- 1
  ut<- id[1]
  for(i in 1:(n-1)){
    if(idd[i]==1){
      j<- j+1
    }else{
      j<- 1
      ut<- c(ut,id[i],id[i+1])
    }
  }
  ut<- c(ut,id[i+1])
  ut1<- c()
  i<- 1

  while(i<length(ut)){
    if(ut[i+1]-ut[i]>20){
      ut1<- c(ut1,ut[i],ut[i+1])
    }
    i<- i+2
  }

  i<- 1
  while(i<length(ut1)){
    if((length(ut1)<3)|(i+2>length(ut1)))break
    if(ut1[i+2]-ut1[i+1]<80){
      ut1<- ut1[c(-i-1,-i-2)]
    }else{
      i<- i+2
    }
  }
  ut1
  return(ut1)
}

interp<- function(y,x,x0){
  n<- length(x0)
  yhat<- matrix(rep(0),n,1)
  n1<- length(x)
  for (i in 1:n) {
    a<- abs(x-x0[i])
    yhat[i]<- y[order(a)[1]]
  }
  return(yhat)
}
###### crt�ǰ�����ȷ����Ĵ��������ܶ��
rt<- more<- less<- error<-crt<- 0
Nt<- 1
jumps.list<-  list()
jumps<- c()
system.time(
  while(Nt<N+1){
    jumps2<- c()
    cat('Simulation ', Nt,'\n')
    ####   ����ȡ�㲽��
    u1<- seq(0.11,0.89,by=0.001)
    nu1<- length(u1)
    DRSStotal<- matrix(rep(0),nu1,1)
    ###############   �����������
    eps<- rnorm(n,0,sigmaeps)
    uj<- runif(n,0,1)
    yj<- gu(uj)+eps
    #############����sigmaeps
    yjs<- yj[order(uj)]
    sigmahat<- 1/2*1/(n-1)*sum((yjs[-1]-yjs[-n])^2)
    sigmahat
    
    ####### BIC׼��ѡ��ڵ�
    for(k in low:up){
      for(degree in 1:3){
        u0<- seq(0.1,0.9,length.out = k)
        fit1<- lm(yj ~ bs(uj, degree = degree, knots = u0,Boundary.knots = c(0,1),intercept=T)-1)
        RSS0<- sum(fit1$residuals^2)
        BIC[degree,k-low+1]<- log(RSS0/n)+(k+degree+1)/n*log(n)
      }
    }
    k0<- ceiling(which.min(BIC)/3)+low-1
    degree<- (which.min(BIC)-1)%%3+1
    q2<- qchisq(1-alpha,degree+1)
    err<-  0.8/(k0-1)
    cat('k0=',k0,'degree=',degree,'\n')
    
    u0<- seq(0.1,0.9,length.out = k0)
    nu0<- length(u0)
    fit1<- lm(yj ~ bs(uj, degree = degree, knots = u0,Boundary.knots = c(0,1),intercept=T)-1)
    yfit1<- fitted(fit1)
    RSS0<- sum(fit1$residuals^2)
    DRSSu<-DRSSu2<-DRSSu3<-DRSSuT<- rep(0,nu1)
    for(i in 1:nu1){
      us<- u0
      m=which(u0==u1[i])
      if(length(m)>0){
        us<- c(u0[-m],rep(u1[i],degree+1))
        us<- sort(us)
      }else{
        us<- c(u0,rep(u1[i],degree+1))
        us<- sort(us)
      }
      fit2<- lm(yj ~ bs(uj, degree = degree, knots = us,Boundary.knots = c(0,1),intercept=T)-1)
      yfit2<- fitted(fit2)
      #ȷ��x������
      it<- order(abs(u0-u1[i]))[1:2]
      it1<- min(it)
      it2<- max(it)
      idM2<- which(uj>=u0[it2]+err|uj<u0[it1])
      RSS2<- sum((yfit1[idM2]-yfit2[idM2])^2)*n/(length(idM2))
      idM3<- which(uj>=u0[it2]|uj<u0[it1]-err)
      RSS3<- sum((yfit1[idM3]-yfit2[idM3])^2)*n/(length(idM3))
      DRSSuT[i]<- max(RSS2,RSS3)
      DRSStotal[i]<- sum((yfit1-yfit2)^2)
      }
    lambda<- max(mean(DRSSuT)/sigmahat-degree-1,0)
    lambdaM[Nt]<- lambda
    q2<- qchisq(1-alpha,degree+1,lambda)*sigmahat
    #cat('lambda=',lambda,q2,'\n')
    #plot(u1,DRSStotal,main = paste('Simulation',Nt))
    #lines(u1,DRSSuT,col='red')
    #abline(h=q2,col='red')
   # abline(h=q3,col='blue')
    #Ѱ���������䣬�ڸ�������ѡȡ����
    id<- which(DRSStotal>q2) 
    if(length(id)==0) next
    ut<- findindex(id)
    i<- 1
    while(i< length(ut)){
      rss<- DRSStotal[ut[i]:ut[i+1]]
      nx<- which(rss==max(rss))
      u.jump<- mean(u1[nx+ut[i]-1])
      jumps<- c(jumps,u.jump)
      jumps2<- c(jumps2,u.jump)
      cat(u.jump,'\n')
      
      du<- abs(u0-u.jump)
      m<- which(du==min(du))
      m<- m[1]
      if(du[m]<err){
        u0<- c(u0[-m],rep(u.jump,degree+1))
        u0<- sort(u0)
      }else{
        u0<- c(u0,rep(u.jump,degree+1))
        u0<- sort(u0)
      }
      i<- i+2
    }
    if(length(jumps2)==2){
      w=abs(jumps2[1]-0.3)+abs(jumps2[2]-0.7)
      if(w<0.05){
        rt<- rt+1
      }else{
        error<- error+1
      }
    }else{
      if(length(jumps2)>2){
        more<- more+1
      }else{
        less<- less+1
      }
    }
    s1<- length(which(jumps2>0.25&jumps2<0.35))
    s2<- length(which(jumps2>0.65&jumps2<0.75))
    if(s1&s2)crt<- crt+1
    
    fit1<- lm(yj ~ bs(uj, degree = degree, knots = u0,Boundary.knots = c(0,1),intercept=T)-1)
    y1<- fitted(fit1)
    yfix[,Nt]<- interp(y1,uj,ufix)
    jumps.list[[Nt]]<- jumps2
    
    #����MISE
    ISE[Nt]<- sum((y1-gu(uj))^2)/n
    id1<- which((uj<0.35)&(uj>0.25))
    ISE3[Nt]<- sum((y1[id1]-gu(uj[id1]))^2)/n
    id2<- which((uj<0.75)&(uj>0.65))
    ISE7[Nt]<- sum((y1[id2]-gu(uj[id2]))^2)/n
    Nt<- Nt+1
  }
)

MISE<- mean(ISE)
MISE3<- mean(ISE3)
MISE7<- mean(ISE7)
cat('Mean lambda=',mean(lambdaM))
cat('MISE=',MISE,'MISE0.3=',MISE3,'MISE0.7=',MISE7,'LMISE=',MISE3+MISE7)


yfinal<- apply(yfix,1,mean)
#####  ��ͼ  #########
mytitle<- paste('N=',N,'n=',n,'sigma=',sigmaeps)
plot(ufix,yfinal,type = 'l',lty=2,col='blue',xlim=c(0,1),ylim=c(0.5,2.5),
     xlab="x",ylab="y",main=mytitle)
lines(ufix,gu(ufix),col='red')
#points(uj,yj)

# ��������
mytitle<- paste('N=',N,'n=',n,'sigma=',sigmaeps)
plot(ufix,yfinal,type = 'l',lty=2,col='blue',xlim=c(0,1),ylim=c(0.5,2.5),
     xlab="x",ylab="y",main=mytitle)
lines(ufix,gu(ufix),col='red')
fL<-apply(yfix,1,quantile,probs = c(0.05,0.95))
lines(ufix,fL[1,],col='blue')
lines(ufix,fL[2,],col='blue')

####### ���ܶȹ���
plot(density(jumps,bw = 0.015,kernel = 'gaussian'),xlim=c(0,1))
J1<- which(jumps<0.35&jumps>0.25)
mean3<- mean(jumps[J1])
sd3<- sd(jumps[J1])
J2<- which(jumps<0.75&jumps>0.65)
mean7<- mean(jumps[J2])
sd7<- sd(jumps[J2])
cat('at 0.3, mean=',mean3,'sd=',sd3,'power=',length(jumps[J1])/N,'\n')
cat('at 0.7, mean=',mean7,'sd=',sd7,'power=',length(jumps[J2])/N,'\n')
###############################################
Len<- rep(0,N)
for(i in 1:N){
  Len[i]<- length(jumps.list[[i]])
}
cat(sum(Len==0),sum(Len==1),sum(Len==2),sum(Len==3),sum(Len>3),'\n')
#save.image('RSSout1_500.2.RData')
